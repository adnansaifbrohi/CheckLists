//
//  ViewController.swift
//  checklists
//
//  Created by Adnan Brohi on 01/03/2022.
//

import UIKit

class ChecklistsViewController: UITableViewController, AddItemViewConrollerDelegate {
    func addItemViewConroller(_ conroller: AddItemViewController, didFinishAdding item: Checklist) {
        //mm
    }
    
    func addItemViewConroller(_ conroller: AddItemViewController, didFinishEditing item: Checklist) {
        //ll
    }
    
    
   // var items = [ChecklistItem]()
    var checklist: Checklist!
    
    //var row4checked = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title  = checklist.name
        
//        loadChecklistItems()
//
//        navigationController?.navigationBar.prefersLargeTitles = true
    
        // Do any additional setup after loading the view.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddItem" {
            let controller = segue.destination as! AddItemViewController
            controller.delegate = self
        } else if segue.identifier == "EditItem" {
            let controller = segue.destination as! AddItemViewController
            controller.delegate = self
            
            if let indexPath = tableView.indexPath(for: sender as! UITableViewCell) {
            
            controller.itemToEdit = checklist.items[indexPath.row]
            }
        }
    }
    
    func configureCheckMark(for cell:UITableViewCell, with item:ChecklistItem){
        
        let label = cell.viewWithTag(1001) as! UILabel
        
        if item.checked {
            label.text = "√"
        }else{
            label.text = ""
        }
    }
    
    func configureText(for cell: UITableViewCell,with item: ChecklistItem){
        let  label = cell.viewWithTag(1000) as! UILabel
        label.text = item.text
    }
    
    // it tells the table viewController about your number of rows that you want to display on the screen
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checklist.items.count
    }
    
    // its help you to create uiTableView cells on the screen
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Checklistitem", for: indexPath)
        let item = checklist.items[indexPath.row]
        configureText(for: cell, with: item)
        configureCheckMark(for: cell, with: item)
        return cell
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        //remove from the model
        checklist.items.remove(at: indexPath.row)
       
        //remove from the tableView
        let indexpaths = [indexPath]
        tableView.deleteRows(at: indexpaths, with: .automatic)
        //saveChecklistItems()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            let item = checklist.items[indexPath.row]
            item.toggleChecked()
        configureCheckMark(for: cell, with: item)
        }
        tableView.deselectRow(at: indexPath, animated: true)
           // saveChecklistItems()
    }
    
    func addItemViewConrollerDidCancel(_ controller: AddItemViewController) {
        navigationController?.popViewController(animated: true)
    }
    func addItemViewConroller(_ conroller: AddItemViewController, didFinishAdding item: ChecklistItem) {
        let newRowIndex = checklist.items.count
        checklist.items.append(item)
        
        let indexPath = IndexPath(row: newRowIndex, section: 0)
        let indexPaths = [indexPath]
        tableView.insertRows(at: indexPaths, with: .automatic)
        navigationController?.popViewController(animated: true)
    }
    func addItemViewConroller(_ conroller: AddItemViewController, didFinishEditing item: ChecklistItem) {
        if let index = checklist.items.index(of: item){
            let indexPath = IndexPath(row: index, section: 0)
            if let cell = tableView.cellForRow(at: indexPath){
                configureText(for: cell, with: item)
            }
        }
        navigationController?.popViewController(animated: true)
    }
    
}
//    func documentsDirectory() -> URL {
//      let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
//      return paths[0]
//    }
//
//    func dataFilePath() -> URL {
//      return documentsDirectory().appendingPathComponent("Checklists.plist")
//    }
//
//    func saveChecklistItems() {
//      let encoder = PropertyListEncoder()
//      do {
//        let data = try encoder.encode(items)
//        try data.write(to: dataFilePath(), options: Data.WritingOptions.atomic)
//      } catch {
//        print("Error encoding item array: \(error.localizedDescription)")
//      }
//    }
//
//    func loadChecklistItems() {
//      let path = dataFilePath()
//      if let data = try? Data(contentsOf: path) {
//        let decoder = PropertyListDecoder()
//        do {
//          items = try decoder.decode([ChecklistItem].self, from: data)
//        } catch {
//        print("Error decoding item array:\(error.localizedDescription)")
//        }
//      }
//    }
//
//
//
//    }
//
//

    
   
  
    
    

